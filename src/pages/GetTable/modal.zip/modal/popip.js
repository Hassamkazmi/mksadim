import React, { useState, useEffect, useRef } from "react";



const popip = (data) => {

    console.log(data,'data')

    return (
        <>
            <div className="popup1 design"  >
                <div className="popupform1">
                    <p>{data.data.TitleAr}</p>
                </div>
            </div>
        </>
    );
};

export default popip;